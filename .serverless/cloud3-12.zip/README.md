# cloud3-12
# Continuous Deployment - Serverless

git clone
git status
git add .
git commit -m "the commit message"
git push

npm init 
npm install serverless
npm install serverless offline --save-dev
